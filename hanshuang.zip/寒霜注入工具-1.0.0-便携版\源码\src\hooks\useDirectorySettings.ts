import { useCallback, useEffect, useRef, useState } from "react";
import { useTranslation } from "react-i18next";
import { toast } from "@/lib/toast";
import { homeDir, join } from "@tauri-apps/api/path";
import { settingsApi, type AppId } from "@/lib/api";
import type { SettingsFormState } from "./useSettingsForm";

export type DirectoryAppId = Exclude<
  AppId,
  "claude-desktop" | "mcode" | "dsh"
>;
type AppDirectoryKey =
  | "claude"
  | "codex"
  | "gemini"
  | "grokbuild"
  | "opencode"
  | "openclaw"
  | "hermes"
  | "pi";
type DirectoryKey = "appConfig" | AppDirectoryKey;

export interface ResolvedDirectories {
  appConfig: string;
  claude: string;
  codex: string;
  gemini: string;
  grokbuild: string;
  opencode: string;
  openclaw: string;
  hermes: string;
  pi: string;
}

// Single source of truth for per-app directory metadata.
const APP_DIRECTORY_META: Record<
  DirectoryAppId,
  { key: AppDirectoryKey; defaultFolder: string }
> = {
  claude: { key: "claude", defaultFolder: ".claude" },
  codex: { key: "codex", defaultFolder: ".codex" },
  gemini: { key: "gemini", defaultFolder: ".gemini" },
  grokbuild: { key: "grokbuild", defaultFolder: ".grok" },
  opencode: { key: "opencode", defaultFolder: ".config/opencode" },
  openclaw: { key: "openclaw", defaultFolder: ".openclaw" },
  hermes: { key: "hermes", defaultFolder: ".hermes" },
  pi: { key: "pi", defaultFolder: ".pi/agent" },
};

const DIRECTORY_KEY_TO_SETTINGS_FIELD: Record<
  AppDirectoryKey,
  keyof SettingsFormState
> = {
  claude: "claudeConfigDir",
  codex: "codexConfigDir",
  gemini: "geminiConfigDir",
  grokbuild: "grokConfigDir",
  opencode: "opencodeConfigDir",
  openclaw: "openclawConfigDir",
  hermes: "hermesConfigDir",
  pi: "piConfigDir",
};

const sanitizeDir = (value?: string | null): string | undefined => {
  if (!value) return undefined;
  const trimmed = value.trim();
  return trimmed.length > 0 ? trimmed : undefined;
};

const computeDefaultAppConfigDir = async (): Promise<string | undefined> => {
  try {
    const home = await homeDir();
    return await join(home, ".cc-switch");
  } catch (error) {
    console.error(
      "[useDirectorySettings] Failed to resolve default app config dir",
      error,
    );
    return undefined;
  }
};

const computeDefaultConfigDir = async (
  app: DirectoryAppId,
): Promise<string | undefined> => {
  try {
    const home = await homeDir();
    return await join(home, APP_DIRECTORY_META[app].defaultFolder);
  } catch (error) {
    console.error(
      "[useDirectorySettings] Failed to resolve default config dir",
      error,
    );
    return undefined;
  }
};

export interface UseDirectorySettingsProps {
  settings: SettingsFormState | null;
  onUpdateSettings: (updates: Partial<SettingsFormState>) => void;
}

export interface UseDirectorySettingsResult {
  appConfigDir?: string;
  resolvedDirs: ResolvedDirectories;
  isLoading: boolean;
  initialAppConfigDir?: string;
  /** 保存成功后把已保存的数据目录换成刚存的值 */
  commitAppConfigDir: (value: string | undefined) => void;
  updateDirectory: (app: DirectoryAppId, value?: string) => void;
  updateAppConfigDir: (value?: string) => void;
  browseDirectory: (app: DirectoryAppId) => Promise<void>;
  browseAppConfigDir: () => Promise<void>;
  resetDirectory: (app: DirectoryAppId) => Promise<void>;
  resetAppConfigDir: () => Promise<void>;
  resetAllDirectories: (overrides?: ResolvedAppDirectoryOverrides) => void;
}

export type ResolvedAppDirectoryOverrides = Partial<
  Record<AppDirectoryKey, string | undefined>
>;

/**
 * useDirectorySettings - 目录管理
 * 负责：
 * - appConfigDir 状态
 * - resolvedDirs 状态
 * - 目录选择（browse）
 * - 目录重置
 * - 默认值计算
 */
export function useDirectorySettings({
  settings,
  onUpdateSettings,
}: UseDirectorySettingsProps): UseDirectorySettingsResult {
  const { t } = useTranslation();

  const [appConfigDir, setAppConfigDir] = useState<string | undefined>(
    undefined,
  );
  const [resolvedDirs, setResolvedDirs] = useState<ResolvedDirectories>({
    appConfig: "",
    claude: "",
    codex: "",
    gemini: "",
    grokbuild: "",
    opencode: "",
    openclaw: "",
    hermes: "",
    pi: "",
  });
  const [isLoading, setIsLoading] = useState(true);

  const defaultsRef = useRef<ResolvedDirectories>({
    appConfig: "",
    claude: "",
    codex: "",
    gemini: "",
    grokbuild: "",
    opencode: "",
    openclaw: "",
    hermes: "",
    pi: "",
  });
  // 已保存的数据目录（保存按钮和「需要重启」都和它比）。ref 给回调用，state 让比较它的
  // 组件在保存后重渲染：保存成功要把它更新成刚存的值，否则保存按钮一直在、改回去存不了
  const initialAppConfigDirRef = useRef<string | undefined>(undefined);
  const [initialAppConfigDir, setInitialAppConfigDir] = useState<
    string | undefined
  >(undefined);
  const commitAppConfigDir = useCallback((value: string | undefined) => {
    initialAppConfigDirRef.current = value;
    setInitialAppConfigDir(value);
  }, []);

  // 加载目录信息
  useEffect(() => {
    let active = true;
    setIsLoading(true);

    const load = async () => {
      try {
        const [
          overrideRaw,
          claudeDir,
          codexDir,
          geminiDir,
          grokDir,
          opencodeDir,
          openclawDir,
          hermesDir,
          piDir,
          defaultAppConfig,
          defaultClaudeDir,
          defaultCodexDir,
          defaultGeminiDir,
          defaultGrokDir,
          defaultOpencodeDir,
          defaultOpenclawDir,
          defaultHermesDir,
          defaultPiDir,
        ] = await Promise.all([
          settingsApi.getAppConfigDirOverride(),
          settingsApi.getConfigDir("claude"),
          settingsApi.getConfigDir("codex"),
          settingsApi.getConfigDir("gemini"),
          settingsApi.getConfigDir("grokbuild"),
          settingsApi.getConfigDir("opencode"),
          settingsApi.getConfigDir("openclaw"),
          settingsApi.getConfigDir("hermes"),
          settingsApi.getConfigDir("pi"),
          computeDefaultAppConfigDir(),
          computeDefaultConfigDir("claude"),
          computeDefaultConfigDir("codex"),
          computeDefaultConfigDir("gemini"),
          computeDefaultConfigDir("grokbuild"),
          computeDefaultConfigDir("opencode"),
          computeDefaultConfigDir("openclaw"),
          computeDefaultConfigDir("hermes"),
          computeDefaultConfigDir("pi"),
        ]);

        if (!active) return;

        const normalizedOverride = sanitizeDir(overrideRaw ?? undefined);

        defaultsRef.current = {
          appConfig: defaultAppConfig ?? "",
          claude: defaultClaudeDir ?? "",
          codex: defaultCodexDir ?? "",
          gemini: defaultGeminiDir ?? "",
          grokbuild: defaultGrokDir ?? "",
          opencode: defaultOpencodeDir ?? "",
          openclaw: defaultOpenclawDir ?? "",
          hermes: defaultHermesDir ?? "",
          pi: defaultPiDir ?? "",
        };

        setAppConfigDir(normalizedOverride);
        commitAppConfigDir(normalizedOverride);

        setResolvedDirs({
          appConfig: normalizedOverride ?? defaultsRef.current.appConfig,
          claude: claudeDir || defaultsRef.current.claude,
          codex: codexDir || defaultsRef.current.codex,
          gemini: geminiDir || defaultsRef.current.gemini,
          grokbuild: grokDir || defaultsRef.current.grokbuild,
          opencode: opencodeDir || defaultsRef.current.opencode,
          openclaw: openclawDir || defaultsRef.current.openclaw,
          hermes: hermesDir || defaultsRef.current.hermes,
          pi: piDir || defaultsRef.current.pi,
        });
      } catch (error) {
        console.error(
          "[useDirectorySettings] Failed to load directory info",
          error,
        );
      } finally {
        if (active) {
          setIsLoading(false);
        }
      }
    };

    void load();
    return () => {
      active = false;
    };
  }, []);

  const previousSettingsRef = useRef(settings);
  const localDirectoryUpdatesRef = useRef<ResolvedAppDirectoryOverrides>({});
  const directoryRevisionsRef = useRef<
    Partial<Record<AppDirectoryKey, number>>
  >({});
  useEffect(() => {
    const previousSettings = previousSettingsRef.current;
    previousSettingsRef.current = settings;
    if (!previousSettings || !settings) return;

    // Refetch can discard a draft. Resolve cleared overrides through the backend,
    // whose defaults may depend on the platform or environment variables.
    for (const { key } of Object.values(APP_DIRECTORY_META)) {
      const field = DIRECTORY_KEY_TO_SETTINGS_FIELD[key];
      const value = sanitizeDir(settings[field] as string | undefined);
      if (
        value === sanitizeDir(previousSettings[field] as string | undefined)
      ) {
        continue;
      }
      if (
        key in localDirectoryUpdatesRef.current &&
        localDirectoryUpdatesRef.current[key] === value
      ) {
        delete localDirectoryUpdatesRef.current[key];
        continue;
      }
      delete localDirectoryUpdatesRef.current[key];
      const revision = (directoryRevisionsRef.current[key] ?? 0) + 1;
      directoryRevisionsRef.current[key] = revision;
      setResolvedDirs((prev) => ({ ...prev, [key]: value ?? "" }));
      if (value !== undefined) continue;

      void settingsApi.getConfigDir(key).then(
        (resolved) => {
          setResolvedDirs((prev) =>
            directoryRevisionsRef.current[key] === revision
              ? { ...prev, [key]: resolved }
              : prev,
          );
        },
        (error) => {
          console.error(
            "[useDirectorySettings] Failed to resolve config dir",
            error,
          );
        },
      );
    }
  }, [settings]);

  useEffect(
    () => () => {
      for (const { key } of Object.values(APP_DIRECTORY_META)) {
        directoryRevisionsRef.current[key] =
          (directoryRevisionsRef.current[key] ?? 0) + 1;
      }
    },
    [],
  );

  const updateDirectoryState = useCallback(
    (key: DirectoryKey, value?: string) => {
      const sanitized = sanitizeDir(value);
      if (key === "appConfig") {
        setAppConfigDir(sanitized);
      } else {
        const field = DIRECTORY_KEY_TO_SETTINGS_FIELD[key];
        // Local edits already update the display below. Do not resolve a local
        // reset against the old persisted override, or let an older read win.
        directoryRevisionsRef.current[key] =
          (directoryRevisionsRef.current[key] ?? 0) + 1;
        localDirectoryUpdatesRef.current[key] = sanitized;
        onUpdateSettings({ [field]: sanitized });
      }

      setResolvedDirs((prev) => {
        const next = sanitized ?? defaultsRef.current[key];
        // Same-ref early-return: unchanged value shouldn't cascade renders
        // through the settings tree.
        if (prev[key] === next) return prev;
        return { ...prev, [key]: next };
      });
    },
    [onUpdateSettings],
  );

  const updateAppConfigDir = useCallback(
    (value?: string) => {
      updateDirectoryState("appConfig", value);
    },
    [updateDirectoryState],
  );

  const updateDirectory = useCallback(
    (app: DirectoryAppId, value?: string) => {
      updateDirectoryState(APP_DIRECTORY_META[app].key, value);
    },
    [updateDirectoryState],
  );

  const browseDirectory = useCallback(
    async (app: DirectoryAppId) => {
      const key = APP_DIRECTORY_META[app].key;
      const settingsField = DIRECTORY_KEY_TO_SETTINGS_FIELD[key];
      const currentValue =
        (settings?.[settingsField] as string | undefined) ?? resolvedDirs[key];

      try {
        const picked = await settingsApi.selectConfigDirectory(currentValue);
        const sanitized = sanitizeDir(picked ?? undefined);
        if (!sanitized) return;
        updateDirectoryState(key, sanitized);
      } catch (error) {
        console.error("[useDirectorySettings] Failed to pick directory", error);
        toast.error(
          t("settings.selectFileFailed", {
            defaultValue: "选择目录失败",
          }),
        );
      }
    },
    [settings, resolvedDirs, t, updateDirectoryState],
  );

  const browseAppConfigDir = useCallback(async () => {
    const currentValue = appConfigDir ?? resolvedDirs.appConfig;
    try {
      const picked = await settingsApi.selectConfigDirectory(currentValue);
      const sanitized = sanitizeDir(picked ?? undefined);
      if (!sanitized) return;
      updateDirectoryState("appConfig", sanitized);
    } catch (error) {
      console.error(
        "[useDirectorySettings] Failed to pick app config directory",
        error,
      );
      toast.error(
        t("settings.selectFileFailed", {
          defaultValue: "选择目录失败",
        }),
      );
    }
  }, [appConfigDir, resolvedDirs.appConfig, t, updateDirectoryState]);

  const resetDirectory = useCallback(
    async (app: DirectoryAppId) => {
      const key = APP_DIRECTORY_META[app].key;
      if (!defaultsRef.current[key]) {
        const fallback = await computeDefaultConfigDir(app);
        if (fallback) {
          defaultsRef.current = {
            ...defaultsRef.current,
            [key]: fallback,
          };
        }
      }
      updateDirectoryState(key, undefined);
    },
    [updateDirectoryState],
  );

  const resetAppConfigDir = useCallback(async () => {
    if (!defaultsRef.current.appConfig) {
      const fallback = await computeDefaultAppConfigDir();
      if (fallback) {
        defaultsRef.current = {
          ...defaultsRef.current,
          appConfig: fallback,
        };
      }
    }
    updateDirectoryState("appConfig", undefined);
  }, [updateDirectoryState]);

  const resetAllDirectories = useCallback(
    (overrides?: ResolvedAppDirectoryOverrides) => {
      for (const { key } of Object.values(APP_DIRECTORY_META)) {
        directoryRevisionsRef.current[key] =
          (directoryRevisionsRef.current[key] ?? 0) + 1;
      }
      setAppConfigDir(initialAppConfigDirRef.current);
      setResolvedDirs({
        appConfig:
          initialAppConfigDirRef.current ?? defaultsRef.current.appConfig,
        claude: overrides?.claude ?? defaultsRef.current.claude,
        codex: overrides?.codex ?? defaultsRef.current.codex,
        gemini: overrides?.gemini ?? defaultsRef.current.gemini,
        grokbuild: overrides?.grokbuild ?? defaultsRef.current.grokbuild,
        opencode: overrides?.opencode ?? defaultsRef.current.opencode,
        openclaw: overrides?.openclaw ?? defaultsRef.current.openclaw,
        hermes: overrides?.hermes ?? defaultsRef.current.hermes,
        pi: overrides?.pi ?? defaultsRef.current.pi,
      });
    },
    [],
  );

  return {
    appConfigDir,
    resolvedDirs,
    isLoading,
    initialAppConfigDir,
    commitAppConfigDir,
    updateDirectory,
    updateAppConfigDir,
    browseDirectory,
    browseAppConfigDir,
    resetDirectory,
    resetAppConfigDir,
    resetAllDirectories,
  };
}
